package vista;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controlador.EmpleadoControlador;
import modeloDTO.EmpleadoDTO;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class VentanaEmpleado extends JFrame {

    private JPanel contentPane;
    private JTextField txtNombre;
    private JTextField txtIdentificacion;
    private EmpleadoControlador controlador;

    public VentanaEmpleado() {
        controlador = new EmpleadoControlador();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        txtNombre = new JTextField();
        txtNombre.setBounds(150, 50, 200, 20);
        contentPane.add(txtNombre);
        txtNombre.setColumns(10);

        txtIdentificacion = new JTextField();
        txtIdentificacion.setBounds(150, 100, 200, 20);
        contentPane.add(txtIdentificacion);
        txtIdentificacion.setColumns(10);

        JButton btnRegistrar = new JButton("Registrar");
        btnRegistrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText();
                String identificacion = txtIdentificacion.getText();

                EmpleadoDTO empleado = new EmpleadoDTO(nombre, identificacion);
                controlador.registrarEmpleado(empleado);

                JOptionPane.showMessageDialog(null, "Empleado registrado con éxito");
            }
        });
        btnRegistrar.setBounds(50, 150, 100, 23);
        contentPane.add(btnRegistrar);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText();

                EmpleadoDTO empleado = controlador.buscarEmpleadoPorNombre(nombre);

                if (empleado != null) {
                    JOptionPane.showMessageDialog(null, "Identificación: " + empleado.getIdentificacion());
                } else {
                    JOptionPane.showMessageDialog(null, "Empleado no encontrado");
                }
            }
        });
        btnBuscar.setBounds(250, 150, 100, 23);
        contentPane.add(btnBuscar);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(50, 50, 50, 14);
        contentPane.add(lblNombre);

        JLabel lblIdentificacion = new JLabel("Identificación:");
        lblIdentificacion.setBounds(50, 100, 80, 14);
        contentPane.add(lblIdentificacion);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    VentanaEmpleado frame = new VentanaEmpleado();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}