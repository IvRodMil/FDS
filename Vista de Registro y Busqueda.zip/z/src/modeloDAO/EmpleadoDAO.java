package modeloDAO;

import java.util.ArrayList;
import java.util.List;
import modeloDTO.EmpleadoDTO;

public class EmpleadoDAO {
    private List<EmpleadoDTO> empleados;

    public EmpleadoDAO() {
        empleados = new ArrayList<>();
    }

    public void agregarEmpleado(EmpleadoDTO empleado) {
        empleados.add(empleado);
    }

    public EmpleadoDTO buscarEmpleadoPorNombre(String nombre) {
        for (EmpleadoDTO empleado : empleados) {
            if (empleado.getNombre().equals(nombre)) {
                return empleado;
            }
        }
        return null;
    }
}
