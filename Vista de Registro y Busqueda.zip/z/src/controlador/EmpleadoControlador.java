package controlador;

import modeloDAO.EmpleadoDAO;
import modeloDTO.EmpleadoDTO;

public class EmpleadoControlador {
	  private EmpleadoDAO empleadoDAO;

	    public EmpleadoControlador() {
	        empleadoDAO = new EmpleadoDAO();
	    }

	    public void registrarEmpleado(EmpleadoDTO empleado) {
	        empleadoDAO.agregarEmpleado(empleado);
	    }

	    public EmpleadoDTO buscarEmpleadoPorNombre(String nombre) {
	        return empleadoDAO.buscarEmpleadoPorNombre(nombre);
	    }
	}
