/**
 * 
 */
/**
 * 
 */
module z {
	requires java.desktop;
}